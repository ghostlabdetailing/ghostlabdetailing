GHOST LAB DETAILING — FREE WEBSITE

Files:
- index.html = complete website

FREE HOSTING:
Recommended: Cloudflare Pages.
1. Create a free Cloudflare account.
2. Workers & Pages → Create application → Pages.
3. Upload/deploy this site (the folder containing index.html).
4. Cloudflare will give you a *.pages.dev address.
5. Add your custom domain under your Pages project → Custom domains.

WIX DOMAIN:
Your Wix-purchased domain can be pointed to an external host by changing its DNS records in Wix. Do not delete email-related MX/TXT records unless you know they are unused.
Cloudflare's exact DNS values can vary by setup, so use the values shown in the Cloudflare Pages custom-domain screen rather than guessing.

IMPORTANT:
The current Facebook/Instagram buttons are placeholders. Replace those two URLs in index.html with your actual profiles.

PHONE:
559-703-1654

If you want to use a different business name/phone/domain, edit the visible text and phone links in index.html.
